nname=input()

print("Hello "+nname+" and welcome to CS Online!")

